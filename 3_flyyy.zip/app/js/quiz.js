"use strict";

var form = function form() {
  var form = document.querySelector('.js-send-form');
  var button = form.querySelector('button[type=submit]');
  var quiz = document.querySelector('.quiz');
  var overlay = document.querySelector('.overlay');
  button.addEventListener('click', function () {
    validate(form);
  });
  form.addEventListener('change', function () {
    validate(form);
  });
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
      if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        form.innerHTML = "<div class=\"quiz__final\">\n\t\t\t\t\t\t<img class=\"quiz__final-img\" src=\"img/quiz/final-icon.png\" alt=\"\">\n\t\t\t\t\t\t<div class=\"quiz__form-title\">\n\t\t\t\t\t\t\t\u0421 \u043F\u0430\u0441\u0438\u0431\u043E \u0437\u0430 \u043F\u0440\u043E\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u0442\u0435\u0441\u0442\u0430!\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<button class=\"btn btn--transparent quiz__final-btn\">\u041E\u041A</button>\n\t\t\t\t\t</div>";
        form.querySelector('.quiz__final-btn').addEventListener('click', function () {
          quiz.classList.remove('active');
          overlay.classList.remove('active');
          var html = document.querySelector('html');
          html.style.overflow = '';
          html.style.marginRight = "0px";
        });
      } else if (this.status === 404) {
        console.log('Ашипка');
      }
    };

    request.open(form.method, form.action, true);
    request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var data = new FormData(form);
    var dataPost = null; // Формируем массив данных для отправки 

    data.forEach(function (value, key) {
      dataPost += '&' + key + '=' + value;
    });

    if (dataPost) {
      request.send(dataPost);
    }
  });

  function validate(form) {
    var error = 0;
    var elems = form.querySelectorAll('.v-req');

    for (var index = 0; index < elems.length; index++) {
      var input = elems[index];

      if (input.classList.contains('_email')) {
        if (emailTest(input)) {
          formAddError(input);
          error++;
        } else {
          formRemoveError(input);
        }
      } else if (input.getAttribute("type") === "checkbox" && input.checked === false) {
        formAddError(input);
        error++;
      } else if (input.value === '') {
        formAddError(input);
        error++;
      } else {
        formRemoveError(input);
      }
    }
  }

  function formAddError(input) {
    input.parentElement.classList.add('_error');
    input.classList.add('_error');
  }

  function formRemoveError(input) {
    input.parentElement.classList.remove('_error');
    input.classList.remove('_error');
  }

  function emailTest(input) {
    return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(input.value);
  }
};

form();

function quiz() {
  var quizWrapper = document.querySelector('.quiz');
  var quiz = quizWrapper.querySelector('.quiz__content');
  var prev = document.querySelector('.quiz__btn--prev');
  var next = document.querySelector('.quiz__btn--next');
  var current = document.querySelector('.quiz__current');
  var imageSliderEl = document.querySelector('.quiz__image-slider');
  var countSlides = document.querySelector('.quiz__count');
  var imageSlider = new Swiper(imageSliderEl, {
    spaceBetween: 50,
    fadeEffect: {
      crossFade: true
    },
    effect: 'fade',
    allowTouchMove: false
  });
  var slider = new Swiper(quiz, {
    allowTouchMove: false,
    autoHeight: true
  });
  countSlides.innerHTML = slider.slides.length;
  prev.addEventListener('click', function (e) {
    e.preventDefault();
    slider.slidePrev();
    imageSlider.slidePrev();
    current.innerHTML = slider.realIndex + 1;

    if (slider.isBeginning) {
      prev.setAttribute('disabled', 'disabled');
    }
  });

  var nextEvent = function nextEvent(e) {
    e.preventDefault();
    slider.slideNext();
    imageSlider.slideNext();
    current.innerHTML = slider.realIndex + 1;
    prev.removeAttribute('disabled');

    if (slider.isEnd) {
      next.removeEventListener('click', nextEvent);
      prev.setAttribute('disabled', 'disabled');
      next.addEventListener('click', function (e) {
        e.preventDefault();
        setTimeout(function () {
          quizWrapper.classList.add('quiz--ended');
        }, 400);
      });
    }
  };

  next.addEventListener('click', nextEvent);
}

quiz();
//# sourceMappingURL=quiz.js.map
