"use strict";

document.addEventListener('DOMContentLoaded', function () {
  bindModal('.js-pupup-btn', true);
});
//# sourceMappingURL=landlord.js.map
