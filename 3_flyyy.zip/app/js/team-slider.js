"use strict";

var mobileSlider = function mobileSlider(sliderSelector, windoWidth, sliderConfig) {
  var slider = document.querySelector(sliderSelector);
  var clientWidth = document.body.clientWidth;
  var yourSlider;

  var sliderInit = function sliderInit() {
    yourSlider = new Swiper(slider, sliderConfig);
    yourSlider.init();
  };

  var resizeHandlerSlider = function resizeHandlerSlider() {
    clientWidth = document.body.clientWidth;

    if (clientWidth <= windoWidth) {
      if (yourSlider) {
        yourSlider.destroy();
      }

      sliderInit();
    } else {
      if (yourSlider) {
        yourSlider.destroy();
      }
    }
  };

  var the_timer;
  window.addEventListener('resize', function () {
    clearTimeout(the_timer);
    the_timer = setTimeout(function () {
      // console.log('resize')
      resizeHandlerSlider();
    }, 75);
  });
  window.addEventListener('load', resizeHandlerSlider);
};
//# sourceMappingURL=team-slider.js.map
