"use strict";

bindModal('.logos__btn', true);
//# sourceMappingURL=media.js.map
