"use strict";

function bindModal(triggerSelector, isOverlayClickable) {
  var trigger = document.querySelectorAll(triggerSelector),
      scroll = calcScroll(),
      overlay = document.querySelector('.overlay');
  var html = document.querySelector('html');
  var body = document.querySelector('html');
  trigger.forEach(function (item) {
    var modalSel = item.getAttribute('data-modal-target');
    var modal = document.querySelector(modalSel);
    var close = modal.querySelector('.js-close');

    if (isOverlayClickable) {
      overlay.addEventListener('click', function () {
        modal.classList.remove('active');
        overlay.classList.remove('active');
        html.style.overflow = '';
        body.style.marginRight = "0px";
        overlay.classList.remove('active');
      });
    }

    item.addEventListener('click', function (e) {
      if (e.target) {
        e.preventDefault();
      }

      modal.classList.add('active');
      overlay.classList.add('active');
      html.style.overflow = 'hidden';
      body.style.marginRight = "".concat(scroll, "px");
      overlay.classList.add('active');
    });
    close.addEventListener('click', function () {
      modal.classList.remove('active');
      overlay.classList.remove('active');
      html.style.overflow = '';
      body.style.marginRight = "0px";
      overlay.classList.remove('active');
    });
  });
}

function calcScroll() {
  var div = document.createElement('div');
  div.style.width = '50px';
  div.style.height = '50px';
  div.style.overflowY = 'scroll';
  div.style.visibility = 'hidden';
  document.body.appendChild(div);
  var scrollWidth = div.offsetWidth - div.clientWidth;
  div.remove();
  return scrollWidth;
}
//# sourceMappingURL=modal.js.map
