new Swiper('.hero-slider__wrapper', {
	slidesPerView: 'auto',
	navigation: {
		nextEl: '.hero-slider__nav--next',
		prevEl: '.hero-slider__nav--prev',
	},
	// autoHeight: true,
})
