document.addEventListener('DOMContentLoaded', () => {
	bindModal('.js-pupup-btn', true)
})